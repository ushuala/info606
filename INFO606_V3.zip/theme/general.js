/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(function () {
    $('[data-toggle="tooltip"]').tooltip();

    /*$('[data-toggle=offcanvas]').click(function (e) {
        $('.row-offcanvas').toggleClass('active');
        $('span').toggleClass('in').toggleClass('hidden-xs').toggleClass('visible-xs');
        return e.preventDefault();
    });*/

})

