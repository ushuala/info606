<?php

if(isset($_POST['texte'])){
    if(file_exists('../script.sh')){
      unlink('../script.sh');
    }
    $fichier = fopen('../script.sh','a');
    $fichier = fopen('../script.sh','r+');
    $text=$_POST['texte'];
    fputs($fichier,$text);
    fclose($fichier);
  echo "Success";
}
else{
  echo "Failure";
}


 ?>
