var pre = "#SBATCH ";

var predicatList = [];

predicatList["nom"] = "-J ";
predicatList["commentaire"] = "--comment ";
predicatList["noeud"] = "-N ";
predicatList["tache"] = "-n ";
predicatList["memoire"] = "-mem ";
predicatList["duree"] = "--time=";
predicatList["gpu"] = "--gres=gpu:";
predicatList["entree"] = "--input ";
predicatList["sortie"] = "--output ";
predicatList["erreur"] = "--error ";

$("form[name='baseForm'] input").change(function() {
	var res = pre;
	if( predicatList[this.name] != null ) {
		if(this.value == "" || this.value == 0) {
			$("#" + this.name).html("");
		}
		else {
			res += predicatList[this.name];

			switch(this.name) {
				case "nom" : case "commentaire":
					res += "\"" + this.value + "\"";
					break;
				case "noeud" : case "tache" : case "memoire" : case "duree" : case "gpu" : case "entree" : case "sortie" : case "erreur":
					res += this.value;
					break;
			}

			$("#" + this.name).html(res);
		}
	}
	else {
		alert("Input non prit en charge: " + this.name);
	}
});

$("form[name='libreForm'] textarea").change(function() {
	$("#libre").html(this.value);
});


$("#previsu").click(function() {
	var pre = "<span>"+$("form[name='moduleForm'] select").val()+"</span> ";
	if($("form[name='moduleForm'] select").val()!=""){
		$.ajax({
	            url: './modules/'+$("form[name='moduleForm'] select").val()+".json",
	            dataType: 'json',
	            success: function(json) {
		            for(var key in json.module.param) {
		           	if($("#"+key).val()!= ""){

		                if(json.module.param[key][0]=="checkbox"){
		                	if($("#"+key).is(':checked')){
		                		pre += "<span id="+key+">"+key+" </span>";
		                	}
		            	}else{
			           		pre += "<span id="+key+">"+key+"="+$("#"+key).val()+" </span>";
		            	}
	                }
	            }
	                $("#"+$("form[name='moduleForm'] select").val()).html(pre);

	            }
	        });
	}
});




$("form[name='moduleForm'] select").change(function() {
	$("#mod").html("");
	$("form[name='moduleForm'] select>option").each(function() {
		if(this.value!="")
			$("#"+this.value).html("");
	});
	if(this.value != ""){
		$("#"+this.value).html(this.value+" ");

	$.ajax({
            url: './modules/'+this.value+".json",
            dataType: 'json',
            success: function(json) {
            	var cpt =0;
           		$("#mod").append('<legend>Paramètres '+json.module.name+'</legend>');
	            for(var key in json.module.param) {
	            	if(cpt == 0){
	            		$("#mod").append('<div class="row">');
	            	}
	            	if(cpt != 0 && cpt%3 == 0){
	            		$("#mod").append('</div><div class="row">');
	            	}

                	$("#mod").append('<div class="col-xs-3 form-group"><label>'+key+'</label><input id='+key+' name='+key+' class="form-control" type='+json.module.param[key][0]+' '+json.module.param[key][1]+'></div>');
	                

	                cpt++;
                }
            }
        });
}

});


$("#ok").click(function() {
	addFichier();
	$("#myModal").modal();

});

/*
$("#download").click(function() {
	$.ajax({
		url:'./php/telechargement.php'
	})
});
*/
$('#download').on('click', function (e) {
	   addFichier();
});

function addFichier(){
	var lignes = $("pre > p:not(.module)").get();
  	var txt="";
  	for(var i =0; i< (lignes.length);i++){		
		if(lignes[i].innerHTML != "") {
			txt=txt+lignes[i].innerHTML+'\n';
		}
	}
	var spans = $("pre > p > span").get();
  	for(var i =0; i< spans.length;i++){
		
		if(spans[i].innerHTML != "") {
			txt=txt+spans[i].innerHTML+' ';
		}
	};
	$.post(
		'./php/creafichier.php',
		{texte : txt+'\n'},
		'text'
	);
}
