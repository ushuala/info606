
function prev(){

	 document.getElementById("previsu").click();

	 var t = setTimeout(prev,1000);

}
