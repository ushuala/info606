<?php

require_once "class/webpage.class.php";

$wp = new WebPage("HPC Portal");

$wp->appendContent(<<<HTML

<div style='margin:50px auto;width:610px;text-align:center;'>Bienvenue sur la V2 !<br>
    <img src='theme/images/logo2016.jpg'><br>
    <img src='theme/images/Grand_Est_Logo.png' style='width:200px;'>
    <img src='theme/images/Logo_RM_quadri.jpg' style='width:100px;margin:0 40px 0 50px;' >
    <img src='theme/images/logoUrca.jpg' style='width:200px;'>
</div>

HTML
);

echo $wp->toHTML(0);