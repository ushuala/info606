<?php

/*--------------------------------------------------------*/

class WebPage{

    /**
     * Le titre de la page
     * @var string $titre
     */
    protected $title = null;

    /**
     * Texte compris entre <head> et </head>
     * @var string $head
     */
    protected $head  = null;

    /**
     * Texte compris entre <main> et </main> dans les balises <body></body>
     * @var string $body
     */
    protected $body  = null;

    /**
     * Javascript mis à la fin de <body>
     * @var string $js
     */
    protected $js  = null;


    /*------------------Constructeur--------------------------*/

    /**
     * Constructeur
     * @param string $title - Le titre de la page
     * @param string $mobileTitle - Le titre de la page sur mobile
     */
    public function __construct($title){
        if($title == ''){
        	throw new Exception('Titre requis dans le constructeur de WebPage');
        }
        $this->title = $title;
    }

    /*----------------------Ajout-----------------------------*/

    /**
     * Ajoute du contenu entre les balises <head>
     * @param string $content - Le contenu
     */
    public function appendToHead($content){
        $this->head .= <<<HTML
        {$content}

HTML;
    }

    /**
     * Ajoute du contenu entre les balises <main>
     * @param string $content - Le contenu
     */
    public function appendContent($content){
        $this->body .= <<<HTML
        {$content}

HTML;
    }

    /**
     * Ajoute du javascript
     * @param string $content - Le contenu
     */
    public function appendJs($content){
        $this->js .= <<<HTML
            {$content}

HTML;
    }

    /**
     * Ajout d'un document javascript à partir d'une url
     * @param string $url - L'url
     */
    public function appendJsUrl($url){
        $this->js .= <<<HTML
        <script type="text/javascript" src="{$url}"></script>

HTML;
    }

    /**
     * Ajoute du css
     * @param string $content - Le contenu
     */
    public function appendCss($content){
        $this->head .= <<<HTML
        <style>
            {$content}
        </style>

HTML;
    }

    /**
     * Ajout d'un document url à partir d'une url
     * @param string $url - L'url
     */
    public function appendCssUrl($url){
        $this->head .= <<<HTML
        <link rel="stylesheet" href="{$url}">

HTML;
    }

    /*---------------------Setteur----------------------------*/

    /**
     * Modificateur de l'attribut title
     * @param string $title - Le nouveau titre
     */
    public function setTitle($title){
        $this->title = $title;
    }

    /*-----------------------HTML-----------------------------*/

    public function toHTML($active){
        $actives = array("", "", "", "", "", "", "", "", "", "", "");
        $actives[$active] = "active"; 

        return $html = <<<HTML
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="./favicon.ico">
        <!--<base href="https://romeoportal.univ-reims.fr/" >-->
        <title>{$this->title}</title>

        <!-- Bootstrap core CSS -->
        <link href="vendor/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Bootstrap theme -->
        <link href="theme/dashboard.css" rel="stylesheet">
        <!-- font-awesome -->
        <link href="vendor/fontawesome-free-5.0.10/web-fonts-with-css/css/fontawesome-all.min.css" rel="stylesheet">
        <!-- Jquery UI -->
        <link href="vendor/jquery-ui-1.12.1.custom/jquery-ui.css" rel="stylesheet">

        <link rel="stylesheet" type="text/css" href="WebsiteTour/css/jquerytour.css" />


        <!-- General -->
        <link href="theme/general.css" rel="stylesheet">
        
        <!-- Jquery -->
        <script src="vendor/bootstrap-3.3.7-dist/js/jquery-3.3.1.min.js"></script>

        <!-- WebsiteTour -->
        <script src="WebsiteTour/js/cufon-yui.js" type="text/javascript"></script>
        <script type="text/javascript">
            Cufon.replace('h1',{ textShadow: '1px 1px #fff'});
            Cufon.replace('h2',{ textShadow: '1px 1px #fff'});
            Cufon.replace('.footer');
        </script>
        {$this->head}
    </head>

    <body role="document">

        <!-- Fixed navbar -->
        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button class="navbar-toggle collapsed" aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" type="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="./"><img src='theme/images/sextant_bleu.png'>HPC PORTAL</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse" aria-expanded="false" style="height: 1px;">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">Help</a></li>
                        <li><a href="#">Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- End navbar -->

        <!-- Contenu de la page -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-3 col-md-2 sidebar">
                    <ul class="nav nav-sidebar">
                        <li class={$actives[0]}><a href='./'><i class="fa fa-home" aria-hidden="true"></i> <span class='in hidden-xs'>Accueil</span></a></li>
                        <li class={$actives[1]}><a href='./'><i class="fa fa-cog" aria-hidden="true"></i> <span class='in hidden-xs'>Configuration</span></a></li>
                        <li class={$actives[2]}><a href='./'><i class="fa fa-list-alt" aria-hidden="true"></i> <span class='in hidden-xs'>Projects</span></a></li>
                        <li class={$actives[3]}><a href='./'><i class="fa fa-paper-plane" aria-hidden="true"></i> <span class='in hidden-xs'>Jobs</span></a></li>
                        <li class={$actives[4]}><a href='createJob.php'><i class="fa fa-pencil-alt" aria-hidden="true"></i> <span class='in hidden-xs'>Création Job</span></a></li>
                        <li class={$actives[5]}><a href='./'><i class="fa fa-calendar" aria-hidden="true"></i> <span class='in hidden-xs'>Réservations</span></a></li>
                        <li class={$actives[6]}><a href='./'><i class="fa fa-desktop" aria-hidden="true"></i> <span class='in hidden-xs'>Visualisation</span></a></li>
                        <li class={$actives[7]}><a href='./'><i class="fa fa-chart-area" aria-hidden="true"></i> <span class='in hidden-xs'>Stats</span></a></li>
                        <li class={$actives[8]}><a href='./'><i class="fa fa-server" aria-hidden="true"></i> <span class='in hidden-xs'>Clusters</span></a></li>
                        <li class={$actives[9]}><a href='./'><i class="fa fa-id-card" aria-hidden="true"></i> <span class='in hidden-xs'>Licences</span></a></li>
                        <li class={$actives[10]}><a href='./'><i class="fa fa-credit-card" aria-hidden="true"></i> <span class='in hidden-xs'>Crédit</span></a></li>
                    </ul>
                </div>

                <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                        {$this->body}                    
                </div>
                
            </div>
        </div>
        <!-- End contenu -->

        <!-- Bootstrap core JavaScript
        ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->

        <script src="vendor/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
        <!-- Jquery UI -->
        <script src="vendor/jquery-ui-1.12.1.custom/jquery-ui.js"></script>

        {$this->js}
        <!--<script src="theme/general.js"></script>-->
    </body>
</html>
HTML;
    }
}