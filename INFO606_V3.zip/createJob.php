<?php

require_once "class/webpage.class.php";

$wp = new WebPage("HPC Portal");

$paramList = array( array("Nom du job", "text", "nom"),
					array("Commentaire", "text", "commentaire"),
					array("Nombre de noeuds", "number", "noeud"),
					array("Nombre de tâches", "number", "tache"),
					array("Mémoire", "text", "memoire"),
					array("Durée", "text", "duree"),
					array("GPU", "text", "gpu"),
					array("Fichier d'entrée", "text", "entree"),
					array("Fichier de sortie", "text", "sortie"),
					array("Fichier d'erreur", "text", "erreur")
				);


$paramHtml = "";

$pre = "<p>#!/bin/bash</p>";
for($i = 0; $i < sizeof($paramList); $i++) {
	$pre .= "<p id={$paramList[$i][2]}></p>";
	if($i == 0){
		$paramHtml .=<<<HTML
		<div class="row">

HTML;
	}
	if($i!=0 and $i%3 == 0){
		$paramHtml .=<<<HTML
		</div>
		<div class="row">

HTML;
	}

	$paramHtml .=<<<HTML
		<div class="col-xs-3 form-group">
		    <label>{$paramList[$i][0]}</label>
		    <input name={$paramList[$i][2]} class="form-control" type={$paramList[$i][1]} min="0">
		</div>

HTML;
	if($i == sizeof($paramList)-1){
		$paramHtml .=<<<HTML
		</div>

HTML;
	}

}

$pre .= "<p id='libre'></p>";

$modulesList = array_diff(scandir("./modules"), array('..', '.')); // Emplacement des fichiers JSON pour les modules
$modulesHtml = "<option></option>";
foreach($modulesList as $module) {
	$module = explode(".", $module)[0];
	$modulesHtml .= "<option>{$module}</option>";
	$pre .= "<p id='{$module}' class='module'></p>";

}

$wp->appendContent(<<<HTML
<body onload='prev();'>
</body>

<h2 class="tour_1">Création de votre job:</h2>

<div>
	<div class="row">
		<form name="baseForm">
			<fieldset>
				<legend class="tour_3">Paramètres généraux</legend>

				{$paramHtml}
			</fieldset>
		</form>
	</div>

	<br>

	<div class="row">
		<form name="libreForm">
			<fieldset>
				<legend class="tour_4">Libre</legend>

				<textarea name="libre" class="col-lg-10" rows="7"></textarea>
			</fieldset>
		</form>
	</div>

	<br>



	<div class="row">
		<form name="moduleForm">
			<fieldset>
				<legend class="tour_5">Modules</legend>

				<div class="form-group">
					<label>Liste des modules disponibles: </label>
					<select class="form-control">{$modulesHtml}</select>
				</div>
				<div id="mod">
				</div>
			</fieldset>
		</form>
	</div>

	<div class="row">
		<div>
	    	<button id="ok" type=button class="btn btn-info tour_6" >OK</button>
	    	<a id="download" href="script.sh" class="button tour_7" download><button type=button class="btn btn-info">Télécharger</button></a>

	    </div>
	    <div >
    		<button id="previsu" type=button class="btn btn-info" style="display:none;">Previsualiser</button>
    	</div>
			<div class="col-lg-5 col-lg-offset-6">
				<div id ="telechargement">
					<!-- Modal -->
					  <div class="modal fade" id="myModal" role="dialog">
					    <div class="modal-dialog">
					    	<div class="modal-content">
						        <div class="modal-header">
						          <h4 class="modal-title">Votre job a été envoyé avec succés</h4>
						        </div>
						        <div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

								</div>
						     </div>
					     
					    </div>
					  </div>
					
				</div>

				
			</div>
    </div>
</div>

<br>

<pre class="tour_2"><h5><b>Prévisualisation du job</b></h5> {$pre}</pre>
<script type="text/javascript" src="WebsiteTour/js/jquery.easing.1.3.js"></script>			


HTML
);

$wp->appendJsUrl("./js/formControl.js");
$wp->appendJsUrl("./js/functions.js");
$wp->appendJsUrl("./js/tuto.js");


echo $wp->toHTML(4);
